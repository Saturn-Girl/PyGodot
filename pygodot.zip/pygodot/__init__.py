from .PyGodot import PyGodotRunVS,PyGodotRunGD
import os

os.system("pip install pygodot")
def functions(Data):
    if Command1 == "PyGodot.RunVS(.vs)":
        print("Running")
    if Command2 == "PyGodot.RunGD(.gd)":
        print("Running")



