import os

os.system('ping youtube.com')
def Functions(__init__):
    import pygodot
